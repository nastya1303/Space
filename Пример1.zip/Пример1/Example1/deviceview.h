#ifndef DEVICEVIEW_H
#define DEVICEVIEW_H

#include <QObject>
#include <QWidget>
#include <QLabel>
#include <QHBoxLayout>

#include "module.h"

/*
 * описание класса TKeyView
 * ВИЗУАЛИЗАЦИЯ КЛЮЧА УСТРОЙСТВА
*/
class TKeyView : public QLabel
{
    Q_OBJECT

public:
    TKeyView(QWidget *parent = 0);

    void view(bool);
};

/*
 * описание класса TCounterView
 * ВИЗУАЛИЗАЦИЯ СЧЕТЧИКА МОДУЛЯ УСТРОЙСТВА
*/
class TCounterView : public QLabel
{
    Q_OBJECT

public:
    TCounterView(QWidget *parent = 0);

    void view(int);
};

/*
 * описание класса TModuleView
 * ВИЗУАЛИЗАЦИЯ МОДУЛЯ УСТРОЙСТВА
*/
class TModuleView : public QWidget
{
    Q_OBJECT

    QHBoxLayout   *hl;

    TKeyView      *kv;
    TCounterView  *cv;

public:
    TModuleView(QWidget *parent = 0);

    void view(TModuleState);
};

#endif // DEVICEVIEW_H
