#include "device.h"

/*
 * реализация класса TDeviceParam
 * ПАРАМЕТРЫ УСТРОЙСТВА
*/
TDeviceParam TDevice::defaultParam = {1,4,3};

/*
 * реализация класса TDevice
 * МОДЕЛЬ УСТРОЙСТВА
*/
TDevice::TDevice() : QObject()
{
    currentParam = defaultParam;
    configure(currentParam.curModuleCount);
    timer = new QTimer();
    timer->setTimerType(Qt::PreciseTimer);
    timer->setInterval(1000);
    connect(timer,SIGNAL(timeout()),this,SLOT(tact()));
}

TDevice::~TDevice()
{
    timer->stop();
    delete timer;
}

void TDevice::configure(int n)
{
    for (int i=0; i<n; i++)
    {
        TModule m;
        modules.append(m);
    }
}

void TDevice::reconfigure(int n)
{
    if (n > 0) configure(n);
    while (n < 0)
    {
        modules.removeLast();
        n++;
    }
}

void TDevice::sendState()
{
    TDeviceState ds;
    ds.active = deviceKey.getState();
    for (int i=0; i<modules.count(); i++)
    {
        ds.mstate.append(modules[i].getState());
    }
    emit deviceState(ds);
}

void TDevice::tact()
{
    for (int i=0; i<modules.count(); i++)
    {
        modules[i].tact();
    }
    sendState();
}

void TDevice::control(int cmd)
{
    if (cmd == 0)
    {
        bool on = deviceKey.control();
        if (on) timer->start();
        else    timer->stop();
    }
    else
        modules[cmd-1].control();
    sendState();
}

void TDevice::countChanged(int n)
{
    reconfigure(n);
    currentParam.curModuleCount += n;
}
