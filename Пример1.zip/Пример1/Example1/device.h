#ifndef DEVICE_H
#define DEVICE_H

#include <QObject>
#include <QVector>
#include <QTimer>

#include "module.h"

/*
 * описание класса TDeviceParam
 * ПАРАМЕТРЫ УСТРОЙСТВА
*/
struct TDeviceParam
{
    int minModuleCount;
    int maxModuleCount;
    int curModuleCount;
};

/*
 * описание класса TDeviceState
 * СОСТОЯНИЕ УСТРОЙСТВА
*/
struct TDeviceState
{
    bool active;
    QVector<TModuleState> mstate;
};

/*
 * описание класса TDevice
 * МОДЕЛЬ УСТРОЙСТВА
*/
class TDevice : public QObject
{
    Q_OBJECT

    static TDeviceParam defaultParam;
    TDeviceParam currentParam;

    QTimer *timer;

    TKey deviceKey;
    QVector<TModule> modules;

    void configure(int);
    void reconfigure(int);
    void sendState();

private slots:
    void tact();

signals:
    void deviceState(TDeviceState);

public:
    TDevice();
    ~TDevice();

    inline TDeviceParam getParam() { return currentParam; };

public slots:
    void control(int);
    void countChanged(int);
};

#endif // DEVICE_H
