#include "deviceview.h"

/*
 * реализация класса TKeyView
 * ВИЗУАЛИЗАЦИЯ КЛЮЧА УСТРОЙСТВА
*/
TKeyView::TKeyView(QWidget *parent)
    : QLabel(parent)
{
    QFont f = font();
    f.setBold(true);
    f.setPointSize(16);
    setFont(f);
    setAutoFillBackground(true);
    setAlignment(Qt::AlignCenter);
    setMinimumSize(QSize(50,50));
    setMaximumSize(QSize(50,50));
    view(false);
}

void TKeyView::view(bool s)
{
    setText(s ? "ON" : "OFF");
    QPalette p;
    p.setColor(QPalette::Window,(s ? Qt::green : Qt::red));
    setPalette(p);
}

/*
 * реализация класса TCounterView
 * ВИЗУАЛИЗАЦИЯ СЧЕТЧИКА МОДУЛЯ УСТРОЙСТВА
*/
TCounterView::TCounterView(QWidget *parent)
    : QLabel(parent)
{
    QFont f = font();
    f.setBold(true);
    f.setPointSize(16);
    setFont(f);
    setAutoFillBackground(true);
    setAlignment(Qt::AlignCenter);
    setMinimumSize(QSize(80,50));
    setMaximumSize(QSize(80,50));
    view(0);
}

void TCounterView::view(int n)
{
    setText(QString().setNum(n));
    QPalette p;
    p.setColor(QPalette::Window,Qt::lightGray);
    setPalette(p);
}

/*
 * реализация класса TModuleView
 * ВИЗУАЛИЗАЦИЯ МОДУЛЯ УСТРОЙСТВА
*/
TModuleView::TModuleView(QWidget *parent)
    : QWidget(parent)
{
    kv = new TKeyView();
    cv = new TCounterView();
    hl = new QHBoxLayout(this);
    hl->addWidget(kv);
    hl->addWidget(cv);
}

void TModuleView::view(TModuleState ms)
{
    kv->view(ms.active);
    cv->view(ms.counter);
}
