#include <QApplication>
#include "interface.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    TDevice d;
    TMainWindow w(&d);
    w.show();

    return a.exec();
}
