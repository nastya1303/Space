#include "interface.h"

/*
 * реализация класса TParamWindow
 * ОКНО ПАРАМЕТРОВ УСТРОЙСТВА
*/
TParamWindow::TParamWindow(TDeviceParam par, QWidget *parent)
    : QWidget(parent)
{
    h = new QLabel("Параметры устройства",this);
    h->setGeometry(20,10,120,50);
    h->setWordWrap(true);
    QFont f = h->font();
    f.setBold(true);
    f.setPointSize(16);
    h->setFont(f);
    l = new QLabel("Число модулей",this);
    l->setGeometry(20,70,120,25);
    n = new QSpinBox(this);
    n->setGeometry(20,100,40,25);
    n->setMinimum(par.minModuleCount);
    n->setMaximum(par.maxModuleCount);
    n->setValue(par.curModuleCount);
    nvalue = par.curModuleCount;
    b1 = new QPushButton("Применить",this);
    b1->setGeometry(20,150,100,25);
    b1->setEnabled(false);
    b2 = new QPushButton("Отменить",this);
    b2->setGeometry(20,180,100,25);
    b2->setEnabled(false);
    setMinimumSize(QSize(160,210));

    connect(n,SIGNAL(valueChanged(int)),this,SLOT(countChanged(int)));
    connect(b1,SIGNAL(pressed()),this,SLOT(changeModuleCount()));
    connect(b2,SIGNAL(pressed()),this,SLOT(restoreModuleCount()));
}

TParamWindow::~TParamWindow()
{
    delete b2;
    delete b1;
    delete n;
    delete l;
    delete h;
}

void TParamWindow::countChanged(int n)
{
    bool m = (nvalue != n);
    b1->setEnabled(m);
    b2->setEnabled(m);
}

void TParamWindow::changeModuleCount()
{
    b1->setEnabled(false);
    b2->setEnabled(false);
    emit changeCount(n->value()-nvalue);
    nvalue = n->value();
}

void TParamWindow::restoreModuleCount()
{
    b1->setEnabled(false);
    b2->setEnabled(false);
    n->setValue(nvalue);
}

/*
 * реализация класса TEventWindow
 * ОКНО УПРАВЛЕНИЕ СОБЫТИЯМИ УСТРОЙСТВА
*/
TEventWindow::TEventWindow(TDeviceParam par, QWidget *parent)
    : QWidget(parent)
{
    h = new QLabel("Управление устройством",this);
    h->setGeometry(20,10,140,50);
    h->setWordWrap(true);
    QFont f = h->font();
    f.setBold(true);
    f.setPointSize(16);
    h->setFont(f);
    l = new QLabel("Выбор модуля",this);
    l->setGeometry(10,70,120,25);
    n = new QSpinBox(this);
    n->setGeometry(130,70,40,25);
    n->setMinimum(par.minModuleCount);
    n->setMaximum(par.curModuleCount);
    n->setValue(par.minModuleCount);
    b1 = new QPushButton("Включить модуль "+QString().setNum(n->value()),this);
    b1->setGeometry(5,120,170,25);
    b2 = new QPushButton("Включить устройство",this);
    b2->setGeometry(5,150,170,25);
    for (int i=0; i<=par.curModuleCount; i++)
        keystates.append(false);
    QPalette p;
    p.setColor(QPalette::Window,Qt::lightGray);
    setPalette(p);
    setAutoFillBackground(true);
    setMinimumSize(QSize(180,150));

    connect(n,SIGNAL(valueChanged(int)),this,SLOT(moduleChanged(int)));
    connect(b1,SIGNAL(pressed()),this,SLOT(deviceControl()));
    connect(b2,SIGNAL(pressed()),this,SLOT(deviceControl()));
}

TEventWindow::~TEventWindow()
{
    delete b2;
    delete b1;
    delete n;
    delete l;
    delete h;
}

void TEventWindow::moduleChanged(int ch)
{
    if (keystates[ch])
        b1->setText("Выключить модуль "+QString().setNum(ch));
    else
        b1->setText("Включить модуль "+QString().setNum(ch));
}

void TEventWindow::deviceControl()
{
    QPushButton *b = (QPushButton*)sender();
    int command = (b == b2 ? 0 : n->value());
    b->setText(b->text().indexOf("Вкл") >= 0 ? "Выключить" : "Включить");
    b->setText(b->text()+(command > 0 ?
                          " модуль "+QString().setNum(command) :
                          " устройство"));
    if (command>0) keystates[command] = !keystates[command];
    emit control(command);
}

void TEventWindow::countChanged(int c)
{
    n->setValue(1);
    n->setMaximum(n->maximum()+c);
    while (c > 0)
    {
        keystates.append(false);
        c--;
    }
    while (c < 0)
    {
        keystates.removeLast();
        c++;
    }
}

/*
 * реализация класса TDeviceWindow
 * ОКНО ОТОБРАЖЕНИЯ УСТРОЙСТВА
*/
TDeviceWindow::TDeviceWindow(TDeviceParam par, QWidget *parent)
    : QWidget(parent)
{
    kv = new TKeyView();
    hl = new QHBoxLayout(this);
    hl->addWidget(kv);
    vl = new QVBoxLayout();
    TModuleView *mv;
    for (int i=0; i<par.curModuleCount;i++)
    {
        mv = new TModuleView();
        mvl.append(mv);
        vl->addWidget(mv);
    }
    hl->addLayout(vl);
    setMinimumSize(QSize(180,150));
}

TDeviceWindow::~TDeviceWindow()
{
    TModuleView *mv;
    while (mvl.count() > 0)
    {
        mv = mvl.takeLast();
        delete mv;
    }
    delete kv;
    delete vl;
    delete hl;
}

void TDeviceWindow::view(TDeviceState ds)
{
    kv->view(ds.active);
    for (int i=0; i<ds.mstate.count();i++)
    {
        mvl.at(i)->view(ds.mstate[i]);
    }
}

void TDeviceWindow::countChanged(int n)
{
    TModuleView *mv;
    while (n > 0)
    {
        mv = new TModuleView();
        mvl.append(mv);
        vl->addWidget(mv);
        n--;
    }
    while (n < 0)
    {
        mv = mvl.takeLast();
        vl->removeWidget(mv);
        delete mv;
        n++;
    }
}

/*
 * реализация класса TMainWindow
 * ГЛАВНОЕ ОКНО ПРИЛОЖЕНИЯ
*/
TMainWindow::TMainWindow(TDevice *dev, QWidget *parent)
    : QWidget(parent)
{
    device = dev;
    TDeviceParam par = dev->getParam();
    pw = new TParamWindow(par);
    ew = new TEventWindow(par);
    dw = new TDeviceWindow(par);
    hl = new QHBoxLayout(this);
    hl->addWidget(pw);
    hl->addWidget(ew);
    hl->addWidget(dw);
    setWindowTitle("Имитатор устройства");

    connect(ew,SIGNAL(control(int)),dev,SLOT(control(int)));
    connect(dev,SIGNAL(deviceState(TDeviceState)),
            this,SLOT(deviceState(TDeviceState)));
    connect(pw,SIGNAL(changeCount(int)),ew,SLOT(countChanged(int)));
    connect(pw,SIGNAL(changeCount(int)),dw,SLOT(countChanged(int)));
    connect(pw,SIGNAL(changeCount(int)),device,SLOT(countChanged(int)));
}

TMainWindow::~TMainWindow()
{
    delete dw;
    delete ew;
    delete pw;
    delete hl;
}

void TMainWindow::deviceState(TDeviceState ds)
{
    dw->view(ds);
}
