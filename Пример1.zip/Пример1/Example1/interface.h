#ifndef INTERFACE_H
#define INTERFACE_H

#include <QWidget>
#include <QLabel>
#include <QSpinBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>

#include "device.h"
#include "deviceview.h"

/*
 * описание класса TParamWindow
 * ОКНО ПАРАМЕТРОВ УСТРОЙСТВА
*/
class TParamWindow : public QWidget
{
    Q_OBJECT

    QLabel      *h;
    QLabel      *l;
    QSpinBox    *n;
    QPushButton *b1;
    QPushButton *b2;

    int nvalue;

private slots:
    void countChanged(int);
    void changeModuleCount();
    void restoreModuleCount();

signals:
    void changeCount(int);

public:
    TParamWindow(TDeviceParam,QWidget *parent = 0);
    ~TParamWindow();
};

/*
 * описание класса TEventWindow
 * ОКНО УПРАВЛЕНИЕ СОБЫТИЯМИ УСТРОЙСТВА
*/
class TEventWindow : public QWidget
{
    Q_OBJECT

    QLabel      *h;
    QLabel      *l;
    QSpinBox    *n;
    QPushButton *b1;
    QPushButton *b2;

    QVector<bool> keystates;

private slots:
    void moduleChanged(int);
    void deviceControl();

signals:
    void control(int);

public:
    TEventWindow(TDeviceParam,QWidget *parent = 0);
    ~TEventWindow();

public slots:
    void countChanged(int);

};

/*
 * описание класса TDeviceWindow
 * ОКНО ОТОБРАЖЕНИЯ УСТРОЙСТВА
*/
class TDeviceWindow : public QWidget
{
    Q_OBJECT

    QHBoxLayout   *hl;
    QVBoxLayout   *vl;

    TKeyView *kv;
    QList<TModuleView*> mvl;

public:
    TDeviceWindow(TDeviceParam,QWidget *parent = 0);
    ~TDeviceWindow();

    void view(TDeviceState);

public slots:
    void countChanged(int);
};

class TMainWindow : public QWidget
{
    Q_OBJECT

    QHBoxLayout   *hl;
    TParamWindow  *pw;
    TEventWindow  *ew;
    TDeviceWindow *dw;

    TDevice *device;

public:
    TMainWindow(TDevice*,QWidget *parent = 0);
    ~TMainWindow();

public slots:
    void deviceState(TDeviceState);
};

#endif // INTERFACE_H
