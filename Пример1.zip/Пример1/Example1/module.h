﻿#ifndef MODULE_H
#define MODULE_H

#include <QObject>

/*
 * описание класса TModuleState
 * СОСТОЯНИЕ МОДУЛЯ УСТРОЙСТВА
*/
struct TModuleState
{
    bool active;
    int  counter;
};

/*
 * описание класса TKey
 * КЛЮЧ УСТРОЙСТВА
*/
class TKey : public QObject
{
    Q_OBJECT

    bool state;
public:
    TKey();
    TKey(const TKey&);
    TKey& operator=(const TKey&);

    inline bool getState() { return state; }
    bool control();
};

/*
 * описание класса TModule
 * МОДУЛь УСТРОЙСТВА
*/
class TModule : public QObject
{
    Q_OBJECT

    TKey moduleKey;
    int  counter;

public:
    TModule();
    TModule(const TModule&);
    TModule& operator=(const TModule&);

    TModuleState getState();
    bool control();

public slots:
    void tact();
};

#endif // MODULE_H
