#include "module.h"

/*
 * реализация класса TKey
 * КЛЮЧ УСТРОЙСТВА
*/
TKey::TKey() : QObject()
{
    state = false;
}

TKey::TKey(const TKey& k) : QObject()
{
    *this = k;
}

TKey& TKey::operator=(const TKey& k)
{
    state=k.state;
    return *this;
};

bool TKey::control()
{
    state = !state;
    return state;
}

/*
 * реализация класса TModule
 * МОДУЛь УСТРОЙСТВА
*/
TModule::TModule() : QObject()
{
    counter = 0;
}

TModule::TModule(const TModule& m) : QObject()
{
    *this = m;
}

TModule& TModule::operator=(const TModule& m)
{
    moduleKey = m.moduleKey;
    counter = m.counter;
    return *this;
}

void TModule::tact()
{
    if (moduleKey.getState())
    {
        counter++;
        counter %= 60;
    }
}

TModuleState TModule::getState()
{
    TModuleState ms;
    ms.active  = moduleKey.getState();
    ms.counter = counter;
    return ms;
}

bool TModule::control()
{
    return moduleKey.control();
}
